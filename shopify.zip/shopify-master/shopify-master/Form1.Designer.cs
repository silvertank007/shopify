﻿namespace oep_dotnet
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.HomeButton = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.ShopifyLabel = new System.Windows.Forms.Label();
            this.ShopifyLogo = new System.Windows.Forms.PictureBox();
            this.ProductButton = new System.Windows.Forms.Button();
            this.CartButton = new System.Windows.Forms.Button();
            this.WelcomeLabel = new System.Windows.Forms.Label();
            this.WeAcceptLabel = new System.Windows.Forms.Label();
            this.PaymentPicture = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ShopifyLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PaymentPicture)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.HomeButton);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.ShopifyLabel);
            this.panel1.Controls.Add(this.ShopifyLogo);
            this.panel1.Controls.Add(this.ProductButton);
            this.panel1.Controls.Add(this.CartButton);
            this.panel1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1224, 90);
            this.panel1.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel4.Location = new System.Drawing.Point(638, 80);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(188, 10);
            this.panel4.TabIndex = 7;
            // 
            // HomeButton
            // 
            this.HomeButton.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.HomeButton.FlatAppearance.BorderSize = 0;
            this.HomeButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.HomeButton.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HomeButton.ForeColor = System.Drawing.Color.White;
            this.HomeButton.Image = ((System.Drawing.Image)(resources.GetObject("HomeButton.Image")));
            this.HomeButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.HomeButton.Location = new System.Drawing.Point(638, 0);
            this.HomeButton.Name = "HomeButton";
            this.HomeButton.Size = new System.Drawing.Size(188, 90);
            this.HomeButton.TabIndex = 6;
            this.HomeButton.Text = "Home   ";
            this.HomeButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.HomeButton.UseVisualStyleBackColor = false;
            this.HomeButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel3.Location = new System.Drawing.Point(1012, 80);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(190, 10);
            this.panel3.TabIndex = 5;
            this.panel3.Visible = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel2.Location = new System.Drawing.Point(826, 80);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(188, 10);
            this.panel2.TabIndex = 4;
            this.panel2.Visible = false;
            // 
            // ShopifyLabel
            // 
            this.ShopifyLabel.AutoSize = true;
            this.ShopifyLabel.Font = new System.Drawing.Font("Century Gothic", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShopifyLabel.ForeColor = System.Drawing.Color.White;
            this.ShopifyLabel.Location = new System.Drawing.Point(113, 21);
            this.ShopifyLabel.Name = "ShopifyLabel";
            this.ShopifyLabel.Size = new System.Drawing.Size(140, 39);
            this.ShopifyLabel.TabIndex = 3;
            this.ShopifyLabel.Text = "ShopiFy";
            // 
            // ShopifyLogo
            // 
            this.ShopifyLogo.Image = ((System.Drawing.Image)(resources.GetObject("ShopifyLogo.Image")));
            this.ShopifyLogo.Location = new System.Drawing.Point(12, 3);
            this.ShopifyLogo.Name = "ShopifyLogo";
            this.ShopifyLogo.Size = new System.Drawing.Size(95, 84);
            this.ShopifyLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ShopifyLogo.TabIndex = 2;
            this.ShopifyLogo.TabStop = false;
            this.ShopifyLogo.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // ProductButton
            // 
            this.ProductButton.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.ProductButton.FlatAppearance.BorderSize = 0;
            this.ProductButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ProductButton.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProductButton.ForeColor = System.Drawing.Color.White;
            this.ProductButton.Image = ((System.Drawing.Image)(resources.GetObject("ProductButton.Image")));
            this.ProductButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ProductButton.Location = new System.Drawing.Point(826, 0);
            this.ProductButton.Name = "ProductButton";
            this.ProductButton.Size = new System.Drawing.Size(188, 90);
            this.ProductButton.TabIndex = 1;
            this.ProductButton.Text = "Product   ";
            this.ProductButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ProductButton.UseVisualStyleBackColor = false;
            this.ProductButton.Click += new System.EventHandler(this.button3_Click);
            // 
            // CartButton
            // 
            this.CartButton.AutoSize = true;
            this.CartButton.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.CartButton.FlatAppearance.BorderSize = 0;
            this.CartButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CartButton.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CartButton.ForeColor = System.Drawing.Color.White;
            this.CartButton.Image = ((System.Drawing.Image)(resources.GetObject("CartButton.Image")));
            this.CartButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CartButton.Location = new System.Drawing.Point(1012, 0);
            this.CartButton.Name = "CartButton";
            this.CartButton.Size = new System.Drawing.Size(190, 90);
            this.CartButton.TabIndex = 1;
            this.CartButton.Text = "Cart      ";
            this.CartButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.CartButton.UseVisualStyleBackColor = false;
            this.CartButton.Click += new System.EventHandler(this.button2_Click);
            // 
            // WelcomeLabel
            // 
            this.WelcomeLabel.AutoSize = true;
            this.WelcomeLabel.Font = new System.Drawing.Font("Century Gothic", 48F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WelcomeLabel.Location = new System.Drawing.Point(399, 121);
            this.WelcomeLabel.Name = "WelcomeLabel";
            this.WelcomeLabel.Size = new System.Drawing.Size(414, 95);
            this.WelcomeLabel.TabIndex = 2;
            this.WelcomeLabel.Text = "Welcome";
            this.WelcomeLabel.Click += new System.EventHandler(this.label3_Click);
            // 
            // WeAcceptLabel
            // 
            this.WeAcceptLabel.AutoSize = true;
            this.WeAcceptLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WeAcceptLabel.Location = new System.Drawing.Point(534, 427);
            this.WeAcceptLabel.Name = "WeAcceptLabel";
            this.WeAcceptLabel.Size = new System.Drawing.Size(148, 32);
            this.WeAcceptLabel.TabIndex = 4;
            this.WeAcceptLabel.Text = "We accept";
            this.WeAcceptLabel.Click += new System.EventHandler(this.label2_Click);
            // 
            // PaymentPicture
            // 
            this.PaymentPicture.Image = ((System.Drawing.Image)(resources.GetObject("PaymentPicture.Image")));
            this.PaymentPicture.Location = new System.Drawing.Point(428, 462);
            this.PaymentPicture.Name = "PaymentPicture";
            this.PaymentPicture.Size = new System.Drawing.Size(262, 82);
            this.PaymentPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.PaymentPicture.TabIndex = 5;
            this.PaymentPicture.TabStop = false;
            this.PaymentPicture.Click += new System.EventHandler(this.PaymentPicture_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1201, 593);
            this.Controls.Add(this.PaymentPicture);
            this.Controls.Add(this.WeAcceptLabel);
            this.Controls.Add(this.WelcomeLabel);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Shopify";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ShopifyLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PaymentPicture)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button ProductButton;
        private System.Windows.Forms.Button CartButton;
        private System.Windows.Forms.PictureBox ShopifyLogo;
        private System.Windows.Forms.Label ShopifyLabel;
        private System.Windows.Forms.Label WelcomeLabel;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button HomeButton;
        private System.Windows.Forms.Label WeAcceptLabel;
        private System.Windows.Forms.PictureBox PaymentPicture;
    }
}

