﻿namespace oep_dotnet
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.HomeButton1 = new System.Windows.Forms.Button();
            this.ProductLabel = new System.Windows.Forms.Label();
            this.ShopifyLogo1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.CartButton1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ShopifyLogo1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.CartButton1);
            this.panel1.Controls.Add(this.HomeButton1);
            this.panel1.Controls.Add(this.ProductLabel);
            this.panel1.Controls.Add(this.ShopifyLogo1);
            this.panel1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1224, 90);
            this.panel1.TabIndex = 1;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel4.Location = new System.Drawing.Point(1033, 80);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(188, 10);
            this.panel4.TabIndex = 7;
            this.panel4.Visible = false;
            // 
            // HomeButton1
            // 
            this.HomeButton1.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.HomeButton1.FlatAppearance.BorderSize = 0;
            this.HomeButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.HomeButton1.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HomeButton1.ForeColor = System.Drawing.Color.White;
            this.HomeButton1.Image = ((System.Drawing.Image)(resources.GetObject("HomeButton1.Image")));
            this.HomeButton1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.HomeButton1.Location = new System.Drawing.Point(1033, 0);
            this.HomeButton1.Name = "HomeButton1";
            this.HomeButton1.Size = new System.Drawing.Size(188, 90);
            this.HomeButton1.TabIndex = 6;
            this.HomeButton1.Text = "Home   ";
            this.HomeButton1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.HomeButton1.UseVisualStyleBackColor = false;
            this.HomeButton1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ProductLabel
            // 
            this.ProductLabel.AutoSize = true;
            this.ProductLabel.Font = new System.Drawing.Font("Century Gothic", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProductLabel.ForeColor = System.Drawing.Color.White;
            this.ProductLabel.Location = new System.Drawing.Point(113, 21);
            this.ProductLabel.Name = "ProductLabel";
            this.ProductLabel.Size = new System.Drawing.Size(140, 39);
            this.ProductLabel.TabIndex = 3;
            this.ProductLabel.Text = "Product";
            // 
            // ShopifyLogo1
            // 
            this.ShopifyLogo1.Image = ((System.Drawing.Image)(resources.GetObject("ShopifyLogo1.Image")));
            this.ShopifyLogo1.Location = new System.Drawing.Point(12, 3);
            this.ShopifyLogo1.Name = "ShopifyLogo1";
            this.ShopifyLogo1.Size = new System.Drawing.Size(95, 84);
            this.ShopifyLogo1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ShopifyLogo1.TabIndex = 2;
            this.ShopifyLogo1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel3.Location = new System.Drawing.Point(846, 80);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(190, 10);
            this.panel3.TabIndex = 7;
            this.panel3.Visible = false;
            // 
            // CartButton1
            // 
            this.CartButton1.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.CartButton1.FlatAppearance.BorderSize = 0;
            this.CartButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CartButton1.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CartButton1.ForeColor = System.Drawing.Color.White;
            this.CartButton1.Image = ((System.Drawing.Image)(resources.GetObject("CartButton1.Image")));
            this.CartButton1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CartButton1.Location = new System.Drawing.Point(846, 0);
            this.CartButton1.Name = "CartButton1";
            this.CartButton1.Size = new System.Drawing.Size(190, 90);
            this.CartButton1.TabIndex = 6;
            this.CartButton1.Text = "Cart      ";
            this.CartButton1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.CartButton1.UseVisualStyleBackColor = false;
            this.CartButton1.Click += new System.EventHandler(this.CartButton1_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1220, 594);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form2";
            this.Text = "Product";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ShopifyLogo1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button HomeButton1;
        private System.Windows.Forms.Label ProductLabel;
        private System.Windows.Forms.PictureBox ShopifyLogo1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button CartButton1;
    }
}